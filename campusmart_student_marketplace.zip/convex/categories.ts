import { v } from "convex/values";
import { query, mutation } from "./_generated/server";

export const getCategories = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("categories").collect();
  },
});

export const getCategoryBySlug = query({
  args: { slug: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();
  },
});

export const seedCategories = mutation({
  args: {},
  handler: async (ctx) => {
    const existingCategories = await ctx.db.query("categories").collect();
    if (existingCategories.length > 0) return;

    const categories = [
      {
        name: "Electronics",
        slug: "electronics",
        description: "Laptops, phones, tablets, and gadgets",
        icon: "📱",
      },
      {
        name: "Books",
        slug: "books",
        description: "Textbooks, novels, and study materials",
        icon: "📚",
      },
      {
        name: "Fashion",
        slug: "fashion",
        description: "Clothing, shoes, and accessories",
        icon: "👕",
      },
      {
        name: "Furniture",
        slug: "furniture",
        description: "Dorm furniture, desks, and storage",
        icon: "🪑",
      },
      {
        name: "Sports & Recreation",
        slug: "sports",
        description: "Sports equipment and outdoor gear",
        icon: "⚽",
      },
      {
        name: "School Supplies",
        slug: "supplies",
        description: "Stationery, calculators, and tools",
        icon: "✏️",
      },
      {
        name: "Transportation",
        slug: "transportation",
        description: "Bikes, scooters, and car accessories",
        icon: "🚲",
      },
      {
        name: "Other",
        slug: "other",
        description: "Everything else",
        icon: "📦",
      },
    ];

    for (const category of categories) {
      await ctx.db.insert("categories", category);
    }
  },
});
