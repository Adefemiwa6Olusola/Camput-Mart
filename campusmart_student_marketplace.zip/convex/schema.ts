import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  profiles: defineTable({
    userId: v.id("users"),
    firstName: v.string(),
    lastName: v.string(),
    university: v.string(),
    major: v.optional(v.string()),
    graduationYear: v.optional(v.number()),
    bio: v.optional(v.string()),
    profileImage: v.optional(v.id("_storage")),
    isVerified: v.boolean(),
  }).index("by_user", ["userId"]),

  categories: defineTable({
    name: v.string(),
    slug: v.string(),
    description: v.string(),
    icon: v.string(),
  }).index("by_slug", ["slug"]),

  listings: defineTable({
    sellerId: v.id("users"),
    title: v.string(),
    description: v.string(),
    price: v.number(),
    categoryId: v.id("categories"),
    condition: v.union(v.literal("new"), v.literal("like-new"), v.literal("good"), v.literal("fair"), v.literal("poor")),
    images: v.array(v.id("_storage")),
    status: v.union(v.literal("active"), v.literal("sold"), v.literal("pending"), v.literal("inactive")),
    contactMethod: v.union(v.literal("email"), v.literal("phone"), v.literal("message")),
    contactInfo: v.optional(v.string()),
    isFeatured: v.boolean(),
    views: v.number(),
  })
    .index("by_seller", ["sellerId"])
    .index("by_category", ["categoryId"])
    .index("by_status", ["status"])
    .index("by_featured", ["isFeatured"])
    .searchIndex("search_listings", {
      searchField: "title",
      filterFields: ["categoryId", "status"],
    }),

  messages: defineTable({
    listingId: v.id("listings"),
    senderId: v.id("users"),
    receiverId: v.id("users"),
    content: v.string(),
    isRead: v.boolean(),
  })
    .index("by_listing", ["listingId"])
    .index("by_sender", ["senderId"])
    .index("by_receiver", ["receiverId"]),

  favorites: defineTable({
    userId: v.id("users"),
    listingId: v.id("listings"),
  })
    .index("by_user", ["userId"])
    .index("by_listing", ["listingId"])
    .index("by_user_and_listing", ["userId", "listingId"]),

  paymentInfo: defineTable({
    userId: v.id("users"),
    bankDetails: v.optional(v.object({
      bankName: v.string(),
      accountNumber: v.string(),
      accountName: v.string(),
    })),
    mobileMoneyDetails: v.optional(v.object({
      provider: v.string(),
      phoneNumber: v.string(),
      accountName: v.string(),
    })),
  }).index("by_user", ["userId"]),

  payments: defineTable({
    listingId: v.id("listings"),
    buyerId: v.id("users"),
    sellerId: v.id("users"),
    amount: v.number(),
    paymentMethod: v.union(v.literal("bank_transfer"), v.literal("mobile_money")),
    proofImageId: v.id("_storage"),
    status: v.union(v.literal("pending"), v.literal("confirmed"), v.literal("rejected")),
  })
    .index("by_buyer", ["buyerId"])
    .index("by_seller", ["sellerId"])
    .index("by_listing", ["listingId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
