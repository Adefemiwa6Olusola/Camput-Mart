import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getCurrentUserPaymentInfo = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const paymentInfo = await ctx.db
      .query("paymentInfo")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    return paymentInfo;
  },
});

export const getSellerPaymentInfo = query({
  args: { sellerId: v.id("users") },
  handler: async (ctx, args) => {
    const paymentInfo = await ctx.db
      .query("paymentInfo")
      .withIndex("by_user", (q) => q.eq("userId", args.sellerId))
      .unique();

    return paymentInfo;
  },
});

export const updatePaymentInfo = mutation({
  args: {
    bankDetails: v.optional(v.object({
      bankName: v.string(),
      accountNumber: v.string(),
      accountName: v.string(),
    })),
    mobileMoneyDetails: v.optional(v.object({
      provider: v.string(),
      phoneNumber: v.string(),
      accountName: v.string(),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const existingPaymentInfo = await ctx.db
      .query("paymentInfo")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingPaymentInfo) {
      await ctx.db.patch(existingPaymentInfo._id, {
        bankDetails: args.bankDetails,
        mobileMoneyDetails: args.mobileMoneyDetails,
      });
      return existingPaymentInfo._id;
    } else {
      return await ctx.db.insert("paymentInfo", {
        userId,
        bankDetails: args.bankDetails,
        mobileMoneyDetails: args.mobileMoneyDetails,
      });
    }
  },
});

export const createPayment = mutation({
  args: {
    listingId: v.id("listings"),
    amount: v.number(),
    paymentMethod: v.union(v.literal("bank_transfer"), v.literal("mobile_money")),
    proofImageId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const listing = await ctx.db.get(args.listingId);
    if (!listing) throw new Error("Listing not found");

    return await ctx.db.insert("payments", {
      listingId: args.listingId,
      buyerId: userId,
      sellerId: listing.sellerId,
      amount: args.amount,
      paymentMethod: args.paymentMethod,
      proofImageId: args.proofImageId,
      status: "pending",
    });
  },
});

export const getUserPayments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const payments = await ctx.db
      .query("payments")
      .withIndex("by_buyer", (q) => q.eq("buyerId", userId))
      .order("desc")
      .collect();

    return await Promise.all(
      payments.map(async (payment) => {
        const listing = await ctx.db.get(payment.listingId);
        const proofUrl = await ctx.storage.getUrl(payment.proofImageId);
        
        return {
          ...payment,
          listing: listing ? {
            title: listing.title,
            price: listing.price,
          } : null,
          proofUrl,
        };
      })
    );
  },
});

export const getSellerPayments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const payments = await ctx.db
      .query("payments")
      .withIndex("by_seller", (q) => q.eq("sellerId", userId))
      .order("desc")
      .collect();

    return await Promise.all(
      payments.map(async (payment) => {
        const listing = await ctx.db.get(payment.listingId);
        const buyer = await ctx.db.get(payment.buyerId);
        const buyerProfile = await ctx.db
          .query("profiles")
          .withIndex("by_user", (q) => q.eq("userId", payment.buyerId))
          .unique();
        const proofUrl = await ctx.storage.getUrl(payment.proofImageId);
        
        return {
          ...payment,
          listing: listing ? {
            title: listing.title,
            price: listing.price,
          } : null,
          buyer: {
            email: buyer?.email,
            firstName: buyerProfile?.firstName,
            lastName: buyerProfile?.lastName,
          },
          proofUrl,
        };
      })
    );
  },
});

export const updatePaymentStatus = mutation({
  args: {
    paymentId: v.id("payments"),
    status: v.union(v.literal("pending"), v.literal("confirmed"), v.literal("rejected")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const payment = await ctx.db.get(args.paymentId);
    if (!payment) throw new Error("Payment not found");
    if (payment.sellerId !== userId) throw new Error("Not authorized");

    await ctx.db.patch(args.paymentId, { status: args.status });

    // If payment is confirmed, mark listing as sold
    if (args.status === "confirmed") {
      await ctx.db.patch(payment.listingId, { status: "sold" });
    }

    return args.paymentId;
  },
});
