import { Link } from "react-router-dom";

interface ListingCardProps {
  listing: {
    _id: string;
    title: string;
    price: number;
    condition: string;
    imageUrls: (string | null)[];
    category?: string;
    seller?: {
      firstName?: string;
      lastName?: string;
    };
    _creationTime: number;
  };
}

export function ListingCard({ listing }: ListingCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString();
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "new":
        return "bg-green-100 text-green-800";
      case "like-new":
        return "bg-blue-100 text-blue-800";
      case "good":
        return "bg-yellow-100 text-yellow-800";
      case "fair":
        return "bg-orange-100 text-orange-800";
      case "poor":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Link to={`/listing/${listing._id}`} className="group">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200">
        {/* Image */}
        <div className="aspect-w-16 aspect-h-12 bg-gray-200">
          {listing.imageUrls && listing.imageUrls[0] ? (
            <img
              src={listing.imageUrls[0]}
              alt={listing.title}
              className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
            />
          ) : (
            <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
              <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-2">
              {listing.title}
            </h3>
            <span className="text-lg font-bold text-blue-600 ml-2">
              {formatPrice(listing.price)}
            </span>
          </div>

          <div className="flex items-center justify-between mb-2">
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getConditionColor(listing.condition)}`}>
              {listing.condition.charAt(0).toUpperCase() + listing.condition.slice(1)}
            </span>
            {listing.category && (
              <span className="text-sm text-gray-500">{listing.category}</span>
            )}
          </div>

          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>
              {listing.seller?.firstName && listing.seller?.lastName
                ? `${listing.seller.firstName} ${listing.seller.lastName}`
                : "Anonymous"}
            </span>
            <span>{formatDate(listing._creationTime)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
