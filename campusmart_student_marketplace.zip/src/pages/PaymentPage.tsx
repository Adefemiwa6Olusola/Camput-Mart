import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function PaymentPage() {
  const { listingId } = useParams<{ listingId: string }>();
  const navigate = useNavigate();
  const listing = useQuery(api.listings.getListing, listingId ? { id: listingId as any } : "skip");
  const sellerPaymentInfo = useQuery(api.payments.getSellerPaymentInfo, listingId ? { sellerId: listing?.sellerId as any } : "skip");
  const generateUploadUrl = useMutation(api.listings.generateUploadUrl);
  const createPayment = useMutation(api.payments.createPayment);
  
  const [paymentMethod, setPaymentMethod] = useState<"bank_transfer" | "mobile_money">("bank_transfer");
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  if (!listingId) {
    return <div>Invalid listing</div>;
  }

  if (listing === undefined || sellerPaymentInfo === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Listing not found</h1>
        </div>
      </div>
    );
  }

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    toast.success(`${type} copied to clipboard`);
    setTimeout(() => setCopied(null), 2000);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!paymentProof) {
      toast.error("Please upload payment proof");
      return;
    }

    setIsSubmitting(true);
    try {
      // Upload payment proof
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": paymentProof.type },
        body: paymentProof,
      });
      
      const json = await result.json();
      if (!result.ok) {
        throw new Error(`Upload failed: ${JSON.stringify(json)}`);
      }
      const { storageId } = json;

      // Create payment record
      await createPayment({
        listingId: listingId as any,
        amount: listing.price,
        paymentMethod,
        proofImageId: storageId,
      });

      toast.success("Payment submitted successfully! Seller will be notified.");
      navigate(`/listing/${listingId}`);
    } catch (error) {
      toast.error("Failed to submit payment");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Complete Payment</h1>
        <p className="text-gray-600 mt-2">Make payment for your purchase</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Order Summary */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Order Summary</h2>
          
          <div className="flex items-start space-x-4 mb-6">
            {listing.imageUrls && listing.imageUrls[0] && (
              <img
                src={listing.imageUrls[0]}
                alt={listing.title}
                className="w-20 h-20 object-cover rounded-lg"
              />
            )}
            <div className="flex-1">
              <h3 className="font-medium text-gray-900">{listing.title}</h3>
              <p className="text-sm text-gray-600 mt-1">{listing.condition}</p>
              <p className="text-lg font-semibold text-blue-600 mt-2">
                {formatPrice(listing.price)}
              </p>
            </div>
          </div>

          <div className="border-t pt-4">
            <div className="flex justify-between items-center text-lg font-semibold">
              <span>Total Amount:</span>
              <span className="text-blue-600">{formatPrice(listing.price)}</span>
            </div>
          </div>
        </div>

        {/* Payment Details */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Payment Details</h2>
          
          {/* Payment Method Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Payment Method
            </label>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  value="bank_transfer"
                  checked={paymentMethod === "bank_transfer"}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="mr-3"
                />
                <span>Bank Transfer</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  value="mobile_money"
                  checked={paymentMethod === "mobile_money"}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="mr-3"
                />
                <span>Mobile Money</span>
              </label>
            </div>
          </div>

          {/* Seller Payment Information */}
          {sellerPaymentInfo && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-3">Seller Payment Information</h3>
              
              {paymentMethod === "bank_transfer" && sellerPaymentInfo.bankDetails && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Bank Name:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.bankDetails.bankName}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.bankDetails!.bankName, "Bank Name")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Bank Name" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Account Number:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.bankDetails.accountNumber}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.bankDetails!.accountNumber, "Account Number")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Account Number" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Account Name:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.bankDetails.accountName}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.bankDetails!.accountName, "Account Name")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Account Name" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === "mobile_money" && sellerPaymentInfo.mobileMoneyDetails && (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Provider:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.mobileMoneyDetails.provider}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.mobileMoneyDetails!.provider, "Provider")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Provider" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Phone Number:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.mobileMoneyDetails.phoneNumber}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.mobileMoneyDetails!.phoneNumber, "Phone Number")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Phone Number" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Account Name:</span>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{sellerPaymentInfo.mobileMoneyDetails.accountName}</span>
                      <button
                        onClick={() => copyToClipboard(sellerPaymentInfo.mobileMoneyDetails!.accountName, "Account Name")}
                        className="text-blue-600 hover:text-blue-700 text-xs"
                      >
                        {copied === "Account Name" ? "✓" : "Copy"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Payment Proof Upload */}
          <form onSubmit={handlePaymentSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload Payment Proof *
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setPaymentProof(e.target.files?.[0] || null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Upload a screenshot or photo of your payment receipt
              </p>
            </div>

            <div className="flex space-x-4">
              <button
                type="button"
                onClick={() => navigate(-1)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Submitting..." : "Submit Payment"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
