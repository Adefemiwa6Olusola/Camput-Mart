import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function PaymentSetupPage() {
  const paymentInfo = useQuery(api.payments.getCurrentUserPaymentInfo);
  const updatePaymentInfo = useMutation(api.payments.updatePaymentInfo);
  
  const [formData, setFormData] = useState({
    // Bank Details
    bankName: "",
    accountNumber: "",
    accountName: "",
    // Mobile Money Details
    mobileProvider: "",
    mobileNumber: "",
    mobileAccountName: "",
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Update form data when payment info loads
  useEffect(() => {
    if (paymentInfo) {
      setFormData({
        bankName: paymentInfo.bankDetails?.bankName || "",
        accountNumber: paymentInfo.bankDetails?.accountNumber || "",
        accountName: paymentInfo.bankDetails?.accountName || "",
        mobileProvider: paymentInfo.mobileMoneyDetails?.provider || "",
        mobileNumber: paymentInfo.mobileMoneyDetails?.phoneNumber || "",
        mobileAccountName: paymentInfo.mobileMoneyDetails?.accountName || "",
      });
    }
  }, [paymentInfo]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.bankName && !formData.mobileProvider) {
      toast.error("Please provide at least one payment method");
      return;
    }

    setIsSubmitting(true);
    try {
      await updatePaymentInfo({
        bankDetails: formData.bankName ? {
          bankName: formData.bankName,
          accountNumber: formData.accountNumber,
          accountName: formData.accountName,
        } : undefined,
        mobileMoneyDetails: formData.mobileProvider ? {
          provider: formData.mobileProvider,
          phoneNumber: formData.mobileNumber,
          accountName: formData.mobileAccountName,
        } : undefined,
      });
      
      toast.success("Payment information updated successfully!");
    } catch (error) {
      toast.error("Failed to update payment information");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (paymentInfo === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Payment Setup</h1>
        <p className="text-gray-600 mt-2">
          Set up your payment information to receive payments from buyers
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Bank Transfer Details */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Bank Transfer Details</h2>
          <p className="text-sm text-gray-600 mb-4">
            Buyers will use these details to transfer money directly to your bank account
          </p>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="bankName" className="block text-sm font-medium text-gray-700 mb-2">
                Bank Name
              </label>
              <input
                type="text"
                id="bankName"
                value={formData.bankName}
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="e.g., First Bank of Nigeria"
              />
            </div>
            
            <div>
              <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-2">
                Account Number
              </label>
              <input
                type="text"
                id="accountNumber"
                value={formData.accountNumber}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="1234567890"
              />
            </div>
            
            <div>
              <label htmlFor="accountName" className="block text-sm font-medium text-gray-700 mb-2">
                Account Name
              </label>
              <input
                type="text"
                id="accountName"
                value={formData.accountName}
                onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="John Doe"
              />
            </div>
          </div>
        </div>

        {/* Mobile Money Details */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Mobile Money Details</h2>
          <p className="text-sm text-gray-600 mb-4">
            Alternative payment method for mobile money transfers
          </p>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="mobileProvider" className="block text-sm font-medium text-gray-700 mb-2">
                Mobile Money Provider
              </label>
              <select
                id="mobileProvider"
                value={formData.mobileProvider}
                onChange={(e) => setFormData({ ...formData, mobileProvider: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              >
                <option value="">Select Provider</option>
                <option value="MTN Mobile Money">MTN Mobile Money</option>
                <option value="Airtel Money">Airtel Money</option>
                <option value="Vodafone Cash">Vodafone Cash</option>
                <option value="Tigo Cash">Tigo Cash</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="mobileNumber" className="block text-sm font-medium text-gray-700 mb-2">
                Mobile Number
              </label>
              <input
                type="tel"
                id="mobileNumber"
                value={formData.mobileNumber}
                onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="+234 801 234 5678"
              />
            </div>
            
            <div>
              <label htmlFor="mobileAccountName" className="block text-sm font-medium text-gray-700 mb-2">
                Account Name
              </label>
              <input
                type="text"
                id="mobileAccountName"
                value={formData.mobileAccountName}
                onChange={(e) => setFormData({ ...formData, mobileAccountName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                placeholder="John Doe"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-6 py-3 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? "Saving..." : "Save Payment Information"}
          </button>
        </div>
      </form>
    </div>
  );
}
