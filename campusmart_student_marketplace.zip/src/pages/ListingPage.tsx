import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState, useEffect } from "react";

export function ListingPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const listing = useQuery(api.listings.getListing, id ? { id: id as any } : "skip");
  const incrementViews = useMutation(api.listings.incrementViews);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  // Increment views when listing loads
  useEffect(() => {
    if (listing && id) {
      incrementViews({ id: id as any });
    }
  }, [listing, id, incrementViews]);

  if (!id) {
    return <div>Listing not found</div>;
  }

  if (listing === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Listing not found</h1>
        </div>
      </div>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "new":
        return "bg-green-100 text-green-800";
      case "like-new":
        return "bg-blue-100 text-blue-800";
      case "good":
        return "bg-yellow-100 text-yellow-800";
      case "fair":
        return "bg-orange-100 text-orange-800";
      case "poor":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleContact = () => {
    if (listing.contactMethod === "email" && listing.seller?.email) {
      window.location.href = `mailto:${listing.seller.email}?subject=Interest in ${listing.title}`;
    } else if (listing.contactMethod === "phone" && listing.contactInfo) {
      window.location.href = `tel:${listing.contactInfo}`;
    } else {
      // For message method, you could implement a messaging system
      alert("Contact seller through the messaging system (feature coming soon!)");
    }
  };

  const handleBuyNow = () => {
    navigate(`/payment/${id}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          {listing.imageUrls && listing.imageUrls.length > 0 ? (
            <div>
              {/* Main Image */}
              <div className="aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg overflow-hidden mb-4">
                <img
                  src={listing.imageUrls[selectedImageIndex] || ""}
                  alt={listing.title}
                  className="w-full h-96 object-cover"
                />
              </div>
              {/* Thumbnail Images */}
              {listing.imageUrls.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {listing.imageUrls.map((url, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImageIndex(index)}
                      className={`aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg overflow-hidden ${
                        selectedImageIndex === index ? "ring-2 ring-emerald-500" : ""
                      }`}
                    >
                      <img
                        src={url || ""}
                        alt={`${listing.title} ${index + 1}`}
                        className="w-full h-20 object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="aspect-w-1 aspect-h-1 bg-gray-200 rounded-lg flex items-center justify-center">
              <svg className="w-24 h-24 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{listing.title}</h1>
            <div className="flex items-center justify-between mb-4">
              <span className="text-3xl font-bold text-emerald-600">{formatPrice(listing.price)}</span>
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getConditionColor(listing.condition)}`}>
                {listing.condition.charAt(0).toUpperCase() + listing.condition.slice(1)}
              </span>
            </div>
            <div className="flex items-center text-sm text-gray-500 mb-4">
              <span className="mr-4">Category: {listing.category}</span>
              <span>Posted: {formatDate(listing._creationTime)}</span>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">Description</h2>
            <p className="text-gray-700 whitespace-pre-wrap">{listing.description}</p>
          </div>

          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-2">Seller Information</h2>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">
                    {listing.seller?.firstName && listing.seller?.lastName
                      ? `${listing.seller.firstName} ${listing.seller.lastName}`
                      : "Anonymous Seller"}
                  </p>
                  <p className="text-sm text-gray-500">
                    Contact via {listing.contactMethod}
                  </p>
                </div>
                <Link
                  to={`/profile/${listing.sellerId}`}
                  className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
                >
                  View Profile
                </Link>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={handleBuyNow}
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              💳 Buy Now
            </button>
            <button
              onClick={handleContact}
              className="w-full bg-white text-emerald-600 py-3 px-6 rounded-lg font-semibold border-2 border-emerald-600 hover:bg-emerald-50 transition-colors"
            >
              💬 Contact Seller
            </button>
            <button className="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
              ❤️ Save to Favorites
            </button>
          </div>

          <div className="mt-6 text-sm text-gray-500">
            <p>Views: {listing.views}</p>
            <p>Listing ID: {listing._id}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
