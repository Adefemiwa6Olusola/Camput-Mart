import { useParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { ListingCard } from "../components/ListingCard";

export function ProfilePage() {
  const { userId } = useParams<{ userId: string }>();
  const profile = useQuery(api.profiles.getProfile, userId ? { userId: userId as any } : "skip");
  const userListings = useQuery(api.listings.getUserListings, userId ? { userId: userId as any } : "skip");

  if (!userId) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">User not found</h1>
        </div>
      </div>
    );
  }

  if (profile === undefined || userListings === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Profile not found</h1>
        </div>
      </div>
    );
  }

  const activeListings = userListings?.filter(listing => listing.status === "active") || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
          {/* Profile Image Placeholder */}
          <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
            <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>

          {/* Profile Info */}
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <h1 className="text-3xl font-bold text-gray-900">
                {profile.firstName} {profile.lastName}
              </h1>
              {profile.isVerified && (
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                  ✓ Verified
                </span>
              )}
            </div>
            
            <div className="space-y-1 text-gray-600">
              <p className="font-medium">{profile.university}</p>
              {profile.major && <p>{profile.major}</p>}
              {profile.graduationYear && <p>Class of {profile.graduationYear}</p>}
            </div>

            {profile.bio && (
              <div className="mt-4">
                <p className="text-gray-700">{profile.bio}</p>
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="flex space-x-8 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{activeListings.length}</div>
              <div className="text-sm text-gray-600">Active Listings</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">
                {userListings?.filter(l => l.status === "sold").length || 0}
              </div>
              <div className="text-sm text-gray-600">Items Sold</div>
            </div>
          </div>
        </div>
      </div>

      {/* User's Listings */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            {profile.firstName}'s Listings
          </h2>
          {activeListings.length > 0 && (
            <span className="text-sm text-gray-500">{activeListings.length} active items</span>
          )}
        </div>

        {activeListings.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {activeListings.map((listing) => (
              <ListingCard key={listing._id} listing={listing} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <div className="text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2 2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No active listings</h3>
            <p className="text-gray-600">{profile.firstName} hasn't posted any items for sale yet.</p>
          </div>
        )}
      </section>
    </div>
  );
}
