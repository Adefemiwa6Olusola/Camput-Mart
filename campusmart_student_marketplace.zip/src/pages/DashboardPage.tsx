import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Link } from "react-router-dom";
import { ListingCard } from "../components/ListingCard";

export function DashboardPage() {
  const profile = useQuery(api.profiles.getCurrentProfile);
  const userListings = useQuery(api.listings.getUserListings, {});

  if (profile === undefined || userListings === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const activeListings = userListings?.filter(listing => listing.status === "active") || [];
  const soldListings = userListings?.filter(listing => listing.status === "sold") || [];
  const inactiveListings = userListings?.filter(listing => listing.status === "inactive") || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600">
              Welcome back, {profile?.firstName}! Manage your listings and profile here.
            </p>
          </div>
          <Link
            to="/create-listing"
            className="mt-4 sm:mt-0 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Create New Listing
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="text-2xl font-bold text-blue-600">{activeListings.length}</div>
            <div className="text-sm text-gray-600">Active Listings</div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="text-2xl font-bold text-green-600">{soldListings.length}</div>
            <div className="text-sm text-gray-600">Sold Items</div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="text-2xl font-bold text-gray-600">{inactiveListings.length}</div>
            <div className="text-sm text-gray-600">Inactive Listings</div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="text-2xl font-bold text-purple-600">
              {userListings?.reduce((sum, listing) => sum + listing.views, 0) || 0}
            </div>
            <div className="text-sm text-gray-600">Total Views</div>
          </div>
        </div>
      </div>

      {/* Active Listings */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Active Listings</h2>
          {activeListings.length > 0 && (
            <span className="text-sm text-gray-500">{activeListings.length} items</span>
          )}
        </div>
        
        {activeListings.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {activeListings.map((listing) => (
              <div key={listing._id} className="relative">
                <ListingCard listing={listing} />
                <div className="absolute top-2 right-2 flex space-x-1">
                  <Link
                    to={`/edit-listing/${listing._id}`}
                    className="bg-white bg-opacity-90 p-1 rounded-full shadow-sm hover:bg-opacity-100"
                  >
                    <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                    </svg>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <div className="text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2 2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No active listings</h3>
            <p className="text-gray-600 mb-4">Start selling by creating your first listing!</p>
            <Link
              to="/create-listing"
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Create Listing
            </Link>
          </div>
        )}
      </section>

      {/* Sold Listings */}
      {soldListings.length > 0 && (
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Sold Items</h2>
            <span className="text-sm text-gray-500">{soldListings.length} items</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {soldListings.map((listing) => (
              <div key={listing._id} className="relative opacity-75">
                <ListingCard listing={listing} />
                <div className="absolute inset-0 bg-green-500 bg-opacity-20 rounded-lg flex items-center justify-center">
                  <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    SOLD
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Profile Section */}
      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Profile</h2>
          <Link
            to={`/profile/${profile?.userId}`}
            className="text-blue-600 hover:text-blue-700 font-medium"
          >
            View Public Profile →
          </Link>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
              <div className="space-y-2">
                <p><span className="font-medium">Name:</span> {profile?.firstName} {profile?.lastName}</p>
                <p><span className="font-medium">Email:</span> {profile?.email}</p>
                <p><span className="font-medium">University:</span> {profile?.university}</p>
                {profile?.major && <p><span className="font-medium">Major:</span> {profile.major}</p>}
                {profile?.graduationYear && <p><span className="font-medium">Graduation:</span> {profile.graduationYear}</p>}
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Status</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <span className="font-medium mr-2">Verification:</span>
                  {profile?.isVerified ? (
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      Verified
                    </span>
                  ) : (
                    <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">
                      Pending
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
          {profile?.bio && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Bio</h3>
              <p className="text-gray-700">{profile.bio}</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
